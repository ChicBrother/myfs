#!/bin/sh
cd /fsclient/
sh stop.sh
sh start.sh

