#!/bin/sh
ulimit -s 65535
ulimit -n 65535
logname=client.log
cd /fsclient/
nohup java -jar client.jar > $logname 2>&1  &
echo FinalSpeed Client start,log file: /fsclient/$logname

